import React, { Component } from 'react';

import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

// intl messages
import IntlMessages from 'Util/IntlMessages';

import { Link } from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Assigned from './ChuteStatus/Assigned';
import AssignedPer from './ChuteStatus/AssignedPer';
import NotAssigned from './ChuteStatus/NotAssigned';
import DonutChart from 'Components/DonutChart/DonutChart';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';


import {graphQlURLPrd} from '../../../services/Config.js';
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/IndvdlSrtrDtls/chuteStatusJson.json';
import axios from 'axios';
import Spinner from 'Util/Spinner';

const mainGrid = {
    padding: '15px',
    height: '280px',
};


class ChuteStatusOverview extends Component {
    constructor(props) {
		super(props);
		this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
		this.sorterid = this.props.sorterId;
		this.state = {  sorterId: "",
			      		assigned: 0,
			      		chuteUtilization: 0,
			      		notAssigned: 1,
			      		assignedPercent: 75,
			      		details: [],
					    isLoading:true
					  };
	}
	
	chuteStatus = {
		chuteStatus_details: json.container.leftSegment.components[0].options.query,
		chuteStatus_Assigned: json.container.leftSegment.components[1].options.query,
		chuteStatus_NotAssigned: json.container.leftSegment.components[2].options.query,
		chuteStatus_assignedPercent: json.container.leftSegment.components[3].options.query
	}
    /*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getAssigned();
		this.getNotAssigned();
		this.getAssignedPercent();
		this.getdetails();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getAssigned();
			this.getNotAssigned();
			this.getAssignedPercent();
			this.getdetails();
		}
	}
	
	getAssigned() {
		let startTime = this.startTime;
		let sorterId = this.sorterid;
		let query = this.chuteStatus.chuteStatus_Assigned;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
							   body: JSON.stringify({ query, variables: { startTime, sorterId } }) 
		}).then(r => r.json()).then(data => { this.setState({ sorterId: data.data.getChuteStatusDetails.sorterId,
															  assigned: data.data.getChuteStatusDetails.assigned,
													          isLoading:false
      														}); 
		}).catch((error) => {
			console.log(error);
			this.setState({ sorterId: "",
				      		assigned: 0,
						    isLoading:false
					 	}); 
		});
	}
	
	getNotAssigned() {
		let startTime = this.startTime;
		let sorterId = this.sorterid;
		let query = this.chuteStatus.chuteStatus_NotAssigned;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
							   body: JSON.stringify({ query, variables: { startTime, sorterId } }) 
		}).then(r => r.json()).then(data => { this.setState({ sorterId: data.data.getChuteStatusDetails.sorterId,
															  notAssigned: data.data.getChuteStatusDetails.notAssigned,
													          isLoading:false
      														}); 
		}).catch((error) => {
			console.log(error);
			this.setState({ sorterId: "",
							notAssigned: 0,
						    isLoading:false
					 	}); 
		});
	}
    
	
	getAssignedPercent() {
		let startTime = this.startTime;
		let sorterId = this.sorterid;
		let query = this.chuteStatus.chuteStatus_assignedPercent;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
							   body: JSON.stringify({ query, variables: { startTime, sorterId } }) 
		}).then(r => r.json()).then(data => { this.setState({ sorterId: data.data.getChuteStatusDetails.sorterId,
															  assignedPercent: data.data.getChuteStatusDetails.assignedPercent,
													          isLoading:false
      														}); 
		}).catch((error) => {
			console.log(error);
			this.setState({ sorterId: "",
							assignedPercent: 0, 
						    isLoading:false
					 	}); 
		});
	}
	
	getdetails() {
		let startTime = this.startTime;
		let sorterId = this.sorterid;
		let query = this.chuteStatus.chuteStatus_details;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
							   body: JSON.stringify({ query, variables: { startTime, sorterId } }) 
		}).then(r => r.json()).then(data => { this.setState({ sorterId: data.data.getChuteStatusDetails.sorterId,
															  details: data.data.getChuteStatusDetails.details,
															  chuteUtilization: data.data.getChuteStatusDetails.chuteUtilization,
													          isLoading:false
      														}); 
		}).catch((error) => {
			console.log(error);
			this.setState({ sorterId: "",
							assignedPercent: 0,
						    isLoading:false
					 	}); 
		});
	}
    
    render () {
	
			//DonutConfig			
			let colors = json.container.leftSegment.components[0].options.colors
			let innerRadius = json.container.leftSegment.components[0].options.innerRadius
			let legend = json.container.leftSegment.components[0].options.legend
			let clickToggle = json.container.leftSegment.components[0].options.clickToggle
			let startAngle = json.container.leftSegment.components[0].options.startAngle
			let toggledOffset = json.container.leftSegment.components[0].options.toggledOffset
			let selectedOffset = json.container.leftSegment.components[0].options.selectedOffset
			let legendLabel = json.container.leftSegment.components[0].options.legendLabel
			
			const { isColorBlind } = this.props;
			
			if(this.state.isLoading){
				return (<RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
											heading={<IntlMessages id="indvlSoterDashbrd.Chute status" />}
											fullBlock >
							<Spinner />
						</RctCollapsibleCard>);
			} else {
				
			}
			
            return(
                <RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
                					heading={<IntlMessages id="indvlSoterDashbrd.Chute status" />}
									fullBlock >
                    <Grid style={mainGrid} container>	
                        <Grid item xs={11} sm={11}>
							<DonutChart colors= {colors}
										innerRadius={innerRadius}
										legend={legend}
										clickToggle={clickToggle}
										startAngle={startAngle}
										toggledOffset={toggledOffset}
										selectedOffset= {selectedOffset}
										totalLabel={legendLabel}
										colorBlindness={isColorBlind}
										data={this.state.details}
										total={this.state.chuteUtilization}
							/>
                        </Grid>
                       
						<div className="right-arrow-chute col-sm-1 col-md-1 col-lg-1" >
                            <Link to={{ pathname: `/app/dashboard/${this.props.nextLink}/chuteDetails` }}>
							
                                &#x203A;
                            </Link>
                        </div>
                    </Grid>
                    
                    <Grid className="chute-bottom-grid" container>
                        <Grid item xs={4} sm={4}>
                            <Assigned value={this.state.assigned}/>
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <NotAssigned value={this.state.notAssigned} />
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <AssignedPer value={this.state.assignedPercent} />
                        </Grid>
                    </Grid>				 
                </RctCollapsibleCard>
            );
    }
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};

export default withRouter(connect(mapStateToProps)(ChuteStatusOverview));
