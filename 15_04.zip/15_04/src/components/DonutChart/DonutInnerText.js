/**
 * @fileOverview The text component in the Donut Chart inner circle.
 * Shows the selected item's label and percent
 * @name DonutInnerText.js
 * @license MIT
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// intl messages
import IntlMessages from 'Util/IntlMessages';

/**
 * @extends {Component}
 */
export default class DonutInnerText extends Component {
    /* React render function */
    render() {
        const {
            item, className, width, formatValues, total
        } = this.props;
        const { label } = item;
        const { percent } = item;
        const half = width / 2;
        const labelClassName = `${className}-label`;
        const percentClassName = `${className}-percent`;

        return <g className={ className }>
            <text
                className={ labelClassName }
                x={ half }
                y={ half }
                fontSize= 'large'
                fontWeight= 'bold'
                textAnchor="middle">
                {<IntlMessages id={`donutChart.${label}`} />}
            </text>
            <text
                className={ percentClassName }
                x={ half }
                y={ half + 20 }
                fontSize= 'large'
                textAnchor="middle">
                { formatValues(percent, total) }
            </text>
        </g>;
    }
}

DonutInnerText.propTypes = {
    item: PropTypes.shape({
        percent: PropTypes.number.isRequired,
        label: PropTypes.string.isRequired,
        className: PropTypes.string,
        isEmpty: PropTypes.boolean
    }).isRequired,
    className: PropTypes.string,
    total: PropTypes.number,
    width: PropTypes.number,
    formatValues: PropTypes.func
};

DonutInnerText.defaultProps = {
    item: {
        label: 'Default',
        percent: 100,
        isEmpty: true
    },
    total: 100,
    className: 'donutchart-innertext',
    width: 500,
    formatValues: percent => percent
};
