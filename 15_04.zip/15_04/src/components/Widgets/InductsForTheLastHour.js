/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/inductsForLastHourJson.json';

// api
import api from 'Api';
import CountUp from 'react-countup';

// intl messages
import IntlMessages from 'Util/IntlMessages';

//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {graphQlURLPrd} from '../../services/Config.js';

import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import SpeedoMeterD3 from './ReactD3Guage';
import NumberClass from 'Util/NumberClass';
let dateFormat = require('dateformat');

import Spinner from 'Util/Spinner';

class InductsForTheLastHour extends Component {

	constructor(props) {
		super(props);
		this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
		this.goalVal = this.props.goal;
		this.sorterid = this.props.sorterid;
		
		this.state = { 
					   label: [],
					   value: [],
					   inducts: 0,
					   inductsPercent: 0,
					   goalValue: 0,
					   isLoading:true
					 };
	}

	inductsForLastHour = {
		inductsForLastHour_CurrentValue: json.container.rightSegment.components[0].options.query,
		inductsForLastHour_CurrentPercentage: json.container.leftSegment.components[0].options.query,
		inductsForLastHour_LastHours: json.container.rightSegment.components[1].options.query
	}
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getCurrentValue();
		this.getCurrentPercentage();
		this.getlastArray();
	}

	//Comparing props and triggering refresh
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getCurrentValue();
			this.getCurrentPercentage();
			this.getlastArray();
		}
	}

	getCurrentValue() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let sorterid = this.sorterid;
		
		/*Inducts per hour*/
		let query = this.inductsForLastHour.inductsForLastHour_CurrentValue;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime, goalVal, sorterid } })
		}).then(r => r.json())
		.then(data => { this.setState({ inducts: data.data.getUSSDataForLastXMins.inducts,
								    	isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ inducts: 0,
						    isLoading:false
						  }); 
		});
		/*End of Inducts per hour*/
	}
	
	getCurrentPercentage() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let sorterid = this.sorterid;
		/*Inducts per hour percentage*/
		let query = this.inductsForLastHour.inductsForLastHour_CurrentPercentage;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime, goalVal, sorterid } })
		}).then(r => r.json())
		.then(data => { this.setState({ inductsPercent: data.data.getUSSDataForLastXMins.inductsPercent,
								    	isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ inductsPercent: 0,
						    isLoading:false
						  }); 
		});
		/*End of Inducts per hour percentage*/
	}
	
	getlastArray() {
		let startTime = this.startTime;
		let goalVal = this.goalVal;
		let sorterid = this.sorterid;
		/*Inducts for Last hours*/
		let query = this.inductsForLastHour.inductsForLastHour_LastHours;
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', },
											   body: JSON.stringify({ query, variables: { startTime, goalVal, sorterid } })
		}).then(r => r.json())
		.then(data => { 
			let label = data.data.getUSSDataForLastXMins.inductsLastXHours == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXHours.map(list => list.hour);
		    let value = data.data.getUSSDataForLastXMins.inductsLastXHours == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXHours.map(list => list.inducts);
		    this.setState({ label: label,
				   			value: value,
				   			isLoading:false
				   		  }); 
		}).catch((error) => {
			console.log(error);
			this.setState({ label: [],
	   						value: [],
						    isLoading:false
						  }); 
		});
		/*End of Inducts Last hours*/
	}
	
	render() {
	
		const { isColorBlind } = this.props;
	
	
		let height = json.container.leftSegment.components[0].options.height
		let width = json.container.leftSegment.components[0].options.width
		let needleLength = json.container.leftSegment.components[0].options.needleLength
		let needleRadius = json.container.leftSegment.components[0].options.needleRadius
		let barWidth = json.container.leftSegment.components[0].options.barWidth
		let textSize = json.container.leftSegment.components[0].options.textSize
		let segments = json.container.leftSegment.components[0].options.segments
		let segmentColors = json.container.leftSegment.components[0].options.segmentColors
		let segmentPercentage = json.container.leftSegment.components[0].options.segmentPercentage
		let needleColor = json.container.leftSegment.components[0].options.needleColor
								
		// speedometer
		let spedometerConfig = {
			height : height,
			width: width,
			needleLength: needleLength,
			needleRadius: needleRadius,
			barWidth: barWidth,
			textSize: textSize,
			segments: segments,
			segmentColors:segmentColors,
			segmentPercentage: segmentPercentage
		}
		
		
		
		let fontColor = json.container.rightSegment.components[0].options.goalFontColor
		let graphBGColor = json.container.rightSegment.components[1].options.BGColor
		let chartLabel = json.container.rightSegment.components[1].options.label
				
		//Check For color blind and change the color
		if(isColorBlind) {
			fontColor = '#1E90FF'
			graphBGColor = '#f8e71c'
			needleColor = "#000"
		}
	
		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										heading={<IntlMessages id="unitsorterDashbrd.indusctFrLstHr" />}
										fullBlock > 
							<Spinner />
					</RctCollapsibleCard>);
		} else {
			// Set the color based on Percentage value 
			const percentage  = this.state.inductsPercent;
			return (
					<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={<IntlMessages id="unitsorterDashbrd.indusctFrLstHr" />}
					fullBlock
					>
					<div className="clearfix">
						<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
							<div className="d-flex">
								<div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
								{/* Speedometer Component */}
								<SpeedoMeterD3
									percent={percentage} // Current Percentage value 
									needleLength={spedometerConfig.needleLength} // Needle Length Range from 0 - 100
									needleRadius={spedometerConfig.needleRadius} //Needle Radius Range from 0 - 10
									needleColor={needleColor} //Needle Color can be hex vlaue or name of color
									barWidth={spedometerConfig.barWidth} //Bar Width Range from be 0 - 50
									height={spedometerConfig.height} //Speedometer Height
									width={spedometerConfig.width} //Speedometer width
									textSize={spedometerConfig.textSize} //Percentage Text Size
									segments={spedometerConfig.segments} //Number of segments for speedometer
									segmentColors={spedometerConfig.segmentColors} //segments colors for speedometer, default #000000
									segmentPercentage={spedometerConfig.segmentPercentage} //segments percentage for speedometer
									colorBlindness={isColorBlind} //flag for color blind config
								/>

								</div>
								<div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
										<span className="counter-point">
											<strong>&nbsp; <NumberClass  number={this.state.inducts} />  / &nbsp;
											<span style={{color: fontColor}}><NumberClass  number={this.props.goal} /></span></strong>
										</span>
									</div>
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
									<div className="lastdays-text">{<IntlMessages id="unitsorterDashbrd.lastXhrs" />}</div>
										<div className="induct-line-bar">
										<TinyAreaChart
											chartdata={this.state.value}
			                     		    labels={this.state.label}
											backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
											borderColor={graphBGColor}
											lineTension="0"
											height={130}
											gradient />
											</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</RctCollapsibleCard>
			);
		}
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};



export default withRouter(connect(mapStateToProps)(InductsForTheLastHour));
