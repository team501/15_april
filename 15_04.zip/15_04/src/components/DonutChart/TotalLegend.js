/**
 * @fileOverview Legend component.
 * Orchestrates all rendering each LegendItem component,
 * based on each item.
 * @name TotalLegend.js
 * @license MIT
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// intl messages
import IntlMessages from 'Util/IntlMessages';

/**
 * @extends {Component}
 */
export default class TotalLegend extends Component {
    /* React render function */
    render() {
        const { className, item, index, width, totalWidth } = this.props;

        const { label, value } = item;
        
        const legendRectClassName = `${className}-rect`;
        const legendLabelClassName = `${className}-label`;
        const sqUnit = width / 10;
        const yOffset = 1.5;
        //add 72 instead of 30 for alignment from legend text
        const position = `translate(${totalWidth - width  + 72}, ${((index * yOffset) * sqUnit)})`;
        return <g
            transform={ position }
            className= { className }
            >
            <text
                className={ legendLabelClassName }
                fontSize= "large"
                x={ 1.3 * sqUnit + (sqUnit / 2) }
                y= { (sqUnit / 2)}
                dy="-1.35em">
                { <IntlMessages id={`donutChart.Chute Utilization`} />}{ ` - ` }<tspan fontSize= "x-large" fontWeight= '600'>{value}</tspan>
            </text>
        </g>;
    }
}

TotalLegend.propTypes = {
    item: PropTypes.shape({
        value: PropTypes.number.isRequired,
        label: PropTypes.string.isRequired
    }).isRequired,
    width: PropTypes.number.isRequired,
    totalWidth: PropTypes.number.isRequired,
    index: PropTypes.number,
    className: PropTypes.string
};

TotalLegend.defaultProps = {
    item: {
        label: 'Total',
        value: 100
    },
    index: 0,
    className: 'donutchart-legend-item',
    width: 250,
    totalWidth: 750
};
