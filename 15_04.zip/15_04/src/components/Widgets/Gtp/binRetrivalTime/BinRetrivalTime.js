import React, { Component } from 'react';
import Authors from './TopAuthors';

//import './landing.css';

class OverallWorkMonitor extends Component {
    render(){
    	var opt = {
    			data: [[5, 6, 15]],
    			colors: ['#7B43A1'],
    			labels: ['Bins'],
    			axis: [10, 30, 45, 60]
    	}
    	
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="componentbg overall-work-monitor">
							
							<Authors />
							
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
